# api.py

import subprocess
import json

class DiscordWebhook:
    def __init__(self, url):
        self.url = url

    def send_message(self, message):
        data = {
            'content': message
        }
        payload = json.dumps(data)
        command = f"curl -X POST -H 'Content-Type: application/json' -d '{payload}' {self.url}"
        try:
            subprocess.run(command, shell=True, check=True)
            print("Nachricht erfolgreich an Webhook gesendet.")
        except subprocess.CalledProcessError as e:
            print(f"Fehler beim Senden der Nachricht: {e}")
