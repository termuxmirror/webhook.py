# webhook.py

from .api import DiscordWebhook
from .send import send_webhook_message
