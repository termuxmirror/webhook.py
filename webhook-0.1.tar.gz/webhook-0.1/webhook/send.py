# send.py

from .api import DiscordWebhook

def send_webhook_message(url, message):
    webhook = DiscordWebhook(url)
    webhook.send_message(message)
