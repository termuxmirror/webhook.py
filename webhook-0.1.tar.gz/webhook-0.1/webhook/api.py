# api.py

import requests

class DiscordWebhook:
    def __init__(self, url):
        self.url = url

    def send_message(self, message):
        data = {
            'content': message
        }
        response = requests.post(self.url, json=data)
        if response.status_code == 200:
            print("Nachricht erfolgreich an Webhook gesendet.")
        else:
            print(f"Fehler beim Senden der Nachricht: {response.status_code}")
